sudo touch /mnt/pmemdir/map_file
sudo chmod -R 777 /mnt/pmemdir/map_file
make
./exce.o
